package com.example.android.justjava;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

import static android.R.id.message;
import static com.example.android.justjava.R.id.bottom;
import static com.example.android.justjava.R.id.personName;
import static com.example.android.justjava.R.id.whipped_cream_checkbox;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {

    int quantity = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {
        EditText personName = (EditText) findViewById(R.id.personName);
        String name = personName.getText().toString();

        CheckBox whippedCreamCheckBox = (CheckBox) findViewById(R.id.whipped_cream_checkbox);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();

        CheckBox chocolateCheckBox = (CheckBox) findViewById(R.id.chocolate_checkbox);
        boolean hasChocolate = chocolateCheckBox.isChecked();

        int price = calculatePrice(hasWhippedCream, hasChocolate);

        String priceMessage = createOrderSummary(price, hasWhippedCream, hasChocolate, name);
        displayMessage(priceMessage);
    }

       /**
     * Calculates the price of the order.
     *
     * // @param price           of order
     * //@param addWhippedCream whether or not the customer wants whipped cream
     * //@param quantity        is the number of cups of coffee ordered
     *///@param addChocolate to specify whether or not the customer want to add chocolate
    // returning the total price
    private int calculatePrice(boolean addWhippedCream, boolean addChocolate) {

        // Price of 1 cup of coffee
        int basePrice = 5;

        // add a dollar for whipped cream
        if (addWhippedCream);
        {
            basePrice = basePrice + 1;
        }
        // add 2 dollars for chocolate
        if (addChocolate);
        {
            basePrice = basePrice + 2;
        }
        // calculate the total order price by multiply by quantity
        return quantity * basePrice;
    }


    public String createOrderSummary(int price, boolean addWhippedCream, boolean addChocolate, String personName) {

        String priceMessage = "\nName: " + personName;
        priceMessage += "\nAdd whipped Cream? " + addWhippedCream;
        priceMessage += "\nAdd chocolate? " + addChocolate;
        priceMessage += "\nQuantity: " + quantity;
        priceMessage += "\nTotal: $" + price;
        priceMessage += "\nThank you!";
        return priceMessage;
    }

    /**
     * This method is called when the plus button is clicked.
     */
    public void increment(View view) {
        quantity = quantity + 1;
        displayQuantity(quantity);
    }

    /**
     * This method is called when the minus button is clicked.
     */
    public void decrement(View view) {
        quantity = quantity - 1;
        displayQuantity(quantity);
    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayQuantity(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }

    /**
     * This method displays the given text on the screen.
     */

    private void displayMessage(String message) {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);

    }
}
